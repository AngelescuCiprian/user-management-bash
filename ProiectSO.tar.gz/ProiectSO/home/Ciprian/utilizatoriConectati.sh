#!/bin/bash
cd ../.. # mergem in folderul principal unde se afla loggedUsers
echo -e "\nUtilizatori autentificati in acest moment: "
cat loggedUsers.txt
